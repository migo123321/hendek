import cv2
import numpy as np
import pynput.keyboard
def cv3cam():


    vid = cv2.VideoCapture(0)


    while(True):
        ret, frame = vid.read()
    
        cv2.imshow('cam',frame)
        if cv2.waitKey(1)& 0xFF == ord('q'):
            break
    vid.release()
    cv2.destroyAllWindows()
def Key ():
    
    print("çalışmaya başladı\n ")
    def emir(harfler):
        print("\a",harfler)
    dinleme = pynput.keyboard.Listener(on_press=emir)

    with dinleme:
        dinleme.join()

